/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package edu.vtdi.has.jamican.hospital.appointment.system;

import javax.swing.*;

public class Login extends javax.swing.JFrame {

    /**
     *s
     */
    public Login() {
        initComponents();
        setLocationRelativeTo(null); // center screen
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        jTextFieldEmail = new javax.swing.JTextField();
        jPasswordField = new javax.swing.JPasswordField();
        jComboBoxRole = new javax.swing.JComboBox<>();
        jButtonLogin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        // TITLE
        jLabel1.setFont(new java.awt.Font("Georgia", 3, 36));
        jLabel1.setText("JAM HOSPITAL SYSTEM");

        // LABELS
        jLabel2.setFont(new java.awt.Font("Rockwell", 0, 18));
        jLabel2.setText("Email:");

        jLabel3.setFont(new java.awt.Font("Rockwell", 0, 18));
        jLabel3.setText("Password:");

        jLabel4.setFont(new java.awt.Font("Rockwell", 0, 18));
        jLabel4.setText("User:");

        // INPUTS
        jTextFieldEmail.setFont(new java.awt.Font("Arial", 0, 14));

        jPasswordField.setFont(new java.awt.Font("Arial", 0, 14));

        jComboBoxRole.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"Patient", "Doctor", "Admin"}
        ));

        // BUTTON
        jButtonLogin.setText("Login");
        jButtonLogin.setFont(new java.awt.Font("Rockwell", 1, 16));
        jButtonLogin.addActionListener(evt -> loginActionPerformed(evt));

        // LAYOUT
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                .addComponent(jLabel1)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2)
                        .addComponent(jLabel3)
                        .addComponent(jLabel4))
                    .addGap(20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTextFieldEmail, 250, 250, 250)
                        .addComponent(jPasswordField, 250, 250, 250)
                        .addComponent(jComboBoxRole, 150, 150, 150)))
                .addComponent(jButtonLogin)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addGap(40)
                .addComponent(jLabel1)
                .addGap(50)

                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldEmail, 30, 30, 30))

                .addGap(15)

                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jPasswordField, 30, 30, 30))

                .addGap(15)

                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxRole, 30, 30, 30))

                .addGap(30)

                .addComponent(jButtonLogin, 40, 40, 40)

                .addGap(50)
        );

        pack();
    }

    // LOGIN LOGIC
    private void loginActionPerformed(java.awt.event.ActionEvent evt) {
        String email = jTextFieldEmail.getText();
        String password = new String(jPasswordField.getPassword());
        String role = jComboBoxRole.getSelectedItem().toString();

        if (email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        // DEMO LOGIN (replace with DB later)
        if (email.equals("admin@gmail.com") && password.equals("1234") && role.equals("Admin")) {
            JOptionPane.showMessageDialog(this, "Admin Login Successful");
        } else if (role.equals("Doctor")) {
            JOptionPane.showMessageDialog(this, "Doctor Login Successful");
        } else if (role.equals("Patient")) {
            JOptionPane.showMessageDialog(this, "Patient Login Successful");
        } else {
            JOptionPane.showMessageDialog(this, "Invalid Credentials");
        }
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Login().setVisible(true));
    }

    // VARIABLES
    private javax.swing.JButton jButtonLogin;
    private javax.swing.JComboBox<String> jComboBoxRole;
    private javax.swing.JLabel jLabel1, jLabel2, jLabel3, jLabel4;
    private javax.swing.JPasswordField jPasswordField;
    private javax.swing.JTextField jTextFieldEmail;
}
  

