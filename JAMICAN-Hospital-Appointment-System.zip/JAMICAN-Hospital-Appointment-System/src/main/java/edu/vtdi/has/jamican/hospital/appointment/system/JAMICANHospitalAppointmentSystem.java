/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.vtdi.has.jamican.hospital.appointment.system;

/**
 *
 * @author joelm
 */
public class JAMICANHospitalAppointmentSystem {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
